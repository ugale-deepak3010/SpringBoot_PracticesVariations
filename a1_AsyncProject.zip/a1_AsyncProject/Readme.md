# Example of Async API
  
  
1. Add @EnableAsync at main class.
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  