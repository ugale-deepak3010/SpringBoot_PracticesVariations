package com.a1_async_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A1AsyncProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
