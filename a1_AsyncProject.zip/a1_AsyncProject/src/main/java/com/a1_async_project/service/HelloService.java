package com.a1_async_project.service;

import java.util.concurrent.CompletableFuture;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class HelloService {

	// @Async methods must return void, 
	// or
	// Future<T>, CompletableFuture<T>, ListenableFuture<T>.

	public String getHuge_sync() {

		String output = "default message ";

		try {
			Thread.sleep(5000);
			output = "Sync process took 5 sec "; // hold the process
		} catch (Exception e) {
			return output + e.getMessage();
		}

		return output;
	}
	
	@Async
	public CompletableFuture<String> getHugeAsync() {
		
		String output = "default message ";

		try {
			Thread.sleep(5000);
			output = "Async process took 5 sec "; //
		} catch (Exception e) {
			output =e.getMessage();
		}

		return CompletableFuture.completedFuture(output);
	}

}
